//下载express  npm i express -S
const express = require('express')
const compression = require('compression')
// 创建web服务器
const app = express()
const port = 68

// 必须写在托管静态资源之前,开启gzip压缩
app.use(compression())
// 托管静态资源
app.use(express.static('./dist'))
app.listen(port, () => console.log(`Server running at  http://127.0.0.1:${port}`))